-- Health Management Database (SQLite)
PRAGMA foreign_keys = ON;

CREATE TABLE patient (
    patient_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    name         TEXT NOT NULL,
    dob          TEXT,
    gender       TEXT CHECK(gender IN ('M','F','O')),
    phone        TEXT UNIQUE,
    blood_group  TEXT
);

CREATE TABLE doctor (
    doctor_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    name           TEXT NOT NULL,
    specialization TEXT,
    phone          TEXT
);

CREATE TABLE appointment (
    appt_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER NOT NULL,
    doctor_id  INTEGER NOT NULL,
    appt_date  TEXT NOT NULL,
    appt_time  TEXT NOT NULL,
    status     TEXT DEFAULT 'Scheduled',
    FOREIGN KEY (patient_id) REFERENCES patient(patient_id) ON DELETE CASCADE,
    FOREIGN KEY (doctor_id)  REFERENCES doctor(doctor_id)
);

CREATE TABLE prescription (
    presc_id INTEGER PRIMARY KEY AUTOINCREMENT,
    appt_id  INTEGER NOT NULL,
    medicine TEXT NOT NULL,
    dosage   TEXT,
    duration TEXT,
    FOREIGN KEY (appt_id) REFERENCES appointment(appt_id) ON DELETE CASCADE
);

CREATE TABLE vitals (
    vital_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id  INTEGER NOT NULL,
    bp          TEXT,
    sugar       REAL,
    weight      REAL,
    heart_rate  INTEGER,
    recorded_on TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patient(patient_id) ON DELETE CASCADE
);

CREATE INDEX idx_appt_patient ON appointment(patient_id);
CREATE INDEX idx_appt_doctor  ON appointment(doctor_id);
CREATE INDEX idx_vitals_patient ON vitals(patient_id);
