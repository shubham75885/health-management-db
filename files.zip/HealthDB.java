import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class HealthDB extends SQLiteOpenHelper {
    private static final String DB_NAME = "health_management.db";
    private static final int DB_VERSION = 1;

    public HealthDB(Context ctx) {
        super(ctx, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE patient (patient_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT NOT NULL, dob TEXT, gender TEXT, phone TEXT UNIQUE, blood_group TEXT)");
        db.execSQL("CREATE TABLE doctor (doctor_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT NOT NULL, specialization TEXT, phone TEXT)");
        db.execSQL("CREATE TABLE appointment (appt_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "patient_id INTEGER NOT NULL, doctor_id INTEGER NOT NULL, appt_date TEXT NOT NULL, " +
                "appt_time TEXT NOT NULL, status TEXT DEFAULT 'Scheduled', " +
                "FOREIGN KEY(patient_id) REFERENCES patient(patient_id) ON DELETE CASCADE, " +
                "FOREIGN KEY(doctor_id) REFERENCES doctor(doctor_id))");
        db.execSQL("CREATE TABLE prescription (presc_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "appt_id INTEGER NOT NULL, medicine TEXT NOT NULL, dosage TEXT, duration TEXT, " +
                "FOREIGN KEY(appt_id) REFERENCES appointment(appt_id) ON DELETE CASCADE)");
        db.execSQL("CREATE TABLE vitals (vital_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "patient_id INTEGER NOT NULL, bp TEXT, sugar REAL, weight REAL, heart_rate INTEGER, " +
                "recorded_on TEXT DEFAULT CURRENT_TIMESTAMP, " +
                "FOREIGN KEY(patient_id) REFERENCES patient(patient_id) ON DELETE CASCADE)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        db.execSQL("DROP TABLE IF EXISTS vitals");
        db.execSQL("DROP TABLE IF EXISTS prescription");
        db.execSQL("DROP TABLE IF EXISTS appointment");
        db.execSQL("DROP TABLE IF EXISTS doctor");
        db.execSQL("DROP TABLE IF EXISTS patient");
        onCreate(db);
    }

    // CREATE
    public long addPatient(String name, String dob, String phone) {
        ContentValues v = new ContentValues();
        v.put("name", name);
        v.put("dob", dob);
        v.put("phone", phone);
        return getWritableDatabase().insert("patient", null, v);
    }

    // READ
    public Cursor getAppointments(int patientId) {
        return getReadableDatabase().rawQuery(
                "SELECT a.appt_date, a.appt_time, d.name, d.specialization, a.status " +
                "FROM appointment a JOIN doctor d ON a.doctor_id = d.doctor_id " +
                "WHERE a.patient_id = ?", new String[]{String.valueOf(patientId)});
    }

    // UPDATE
    public int updateStatus(int apptId, String status) {
        ContentValues v = new ContentValues();
        v.put("status", status);
        return getWritableDatabase().update("appointment", v, "appt_id=?",
                new String[]{String.valueOf(apptId)});
    }

    // DELETE
    public int deletePatient(int id) {
        return getWritableDatabase().delete("patient", "patient_id=?",
                new String[]{String.valueOf(id)});
    }
}
