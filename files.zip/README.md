# Health Management Database (SQLite)

A relational database design for a mobile health management app, implemented in SQLite for Android.

## Features
- Patient and doctor registration
- Appointment booking and status tracking
- Prescription records
- Health vitals logging (BP, sugar, weight, heart rate)

## ER Design

| Entity | Key attributes | Relationship |
|---|---|---|
| Patient | patient_id (PK), name, dob, gender, phone, blood_group | 1 patient → many appointments, vitals |
| Doctor | doctor_id (PK), name, specialization, phone | 1 doctor → many appointments |
| Appointment | appt_id (PK), patient_id (FK), doctor_id (FK), date, time, status | Links patient and doctor |
| Prescription | presc_id (PK), appt_id (FK), medicine, dosage, duration | Many per appointment |
| Vitals | vital_id (PK), patient_id (FK), bp, sugar, weight, heart_rate, recorded_on | Many per patient |

All tables are in 3NF; foreign keys enforce integrity.

## Project Files
| File | Description |
|---|---|
| `schema.sql` | Table definitions (DDL) and indexes |
| `sample_data_and_queries.sql` | Sample inserts and useful queries |
| `HealthDB.java` | Android `SQLiteOpenHelper` with CRUD methods |

## How to Run
**SQLite CLI**
```bash
sqlite3 health.db < schema.sql
sqlite3 health.db < sample_data_and_queries.sql
```

**Android:** copy `HealthDB.java` into your app package and use:
```java
HealthDB db = new HealthDB(this);
db.addPatient("Asha Patil", "2000-05-14", "9876543210");
```

## Best Practices
- Use parameterised queries to prevent SQL injection
- Run DB operations off the main thread (or use Room)
- Index foreign keys; use transactions for multi-step writes
- Encrypt sensitive medical data (e.g. SQLCipher) and follow data-protection laws
- Sync to the cloud with Firebase Firestore if needed

## License
MIT
