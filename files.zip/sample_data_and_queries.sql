-- Sample data
INSERT INTO patient (name, dob, gender, phone, blood_group) VALUES ('Asha Patil', '2000-05-14', 'F', '9876543210', 'B+');
INSERT INTO doctor (name, specialization, phone) VALUES ('Dr. Rao', 'General Physician', '9123456780');
INSERT INTO appointment (patient_id, doctor_id, appt_date, appt_time) VALUES (1, 1, date('now'), '10:30');
INSERT INTO prescription (appt_id, medicine, dosage, duration) VALUES (1, 'Paracetamol', '500 mg twice daily', '3 days');
INSERT INTO vitals (patient_id, bp, sugar, weight, heart_rate) VALUES (1, '120/80', 95.0, 58.5, 72);

-- Latest vitals of a patient
SELECT * FROM vitals WHERE patient_id = 1 ORDER BY recorded_on DESC LIMIT 1;

-- Today's appointments with names
SELECT p.name AS patient, d.name AS doctor, a.appt_time
FROM appointment a
JOIN patient p ON a.patient_id = p.patient_id
JOIN doctor  d ON a.doctor_id  = d.doctor_id
WHERE a.appt_date = date('now');

-- Average blood sugar per patient
SELECT patient_id, AVG(sugar) AS avg_sugar FROM vitals GROUP BY patient_id;
